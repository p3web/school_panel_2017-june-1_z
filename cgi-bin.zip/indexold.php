<!DOCTYPE html>
<html lang="en">
<head>
  <title>Ancestry Atlas</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- Add venobox -->
  <link rel="stylesheet" href="venobox/venobox.css" type="text/css" media="screen" />
  <script type="text/javascript" src="venobox/venobox.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  
  <style>
  @font-face {	
	font-family:'MuseoSans_300';
    src:url('fonts/MuseoSans_300.ttf') format('truetype');
	font-weight: normal;
	font-style: normal;
	
}
.btnspecial{
	color:#000;
	background-color:#cfe3d2;
	
	}
 .btnspecial:hover{
	background-color:#99b48c;
	color:#000;
	}
.gradientcolorone{
	/* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#ffffff+0,ffffff+49,ff8c87+49,ff8c87+100 */
background: #ffffff; /* Old browsers */
background: -moz-linear-gradient(top, #ffffff 0%, #ffffff 49%, #ff8c87 49%, #ff8c87 100%); /* FF3.6-15 */
background: -webkit-linear-gradient(top, #ffffff 0%,#ffffff 49%,#ff8c87 49%,#ff8c87 100%); /* Chrome10-25,Safari5.1-6 */
background: linear-gradient(to bottom, #ffffff 0%,#ffffff 49%,#ff8c87 49%,#ff8c87 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ffffff', endColorstr='#ff8c87',GradientType=0 ); /* IE6-9 */
}
  </style>
<script>
	$(document).ready(function(){
		/* default settings */
		$('.venobox').venobox(); 
		

		$('.demo').venobox({
			framewidth: 'auto',
			frameheight: 'auto',
			titleattr: '',
			border: '2px',
			bgcolor: '#fff',
			numeratio: true,
			overlayclose: true 
		});
		/* auto-open #firstlink on page load */
		$("#firstlink").venobox().trigger('click');
	})
</script>
</head>
<body>


<div id="wrap">
	
	<div class="container-fluid">
    	<?php include 'header.php';?>
        
        <div class="row" >
        	<div class="col-sm-2"></div>
            <div class="col-sm-8">
            	<div class="row">
                	<div class="col-sm-12 text-center welcome" style="font-size:1.500em; padding:3.250em 0em 3.250em 0em;" >
                    
	

                    		Welcome to Ancestry Atlas.<br> 
                            Discover the diversity of your community with our simple tool.
                 
                    </div>
                </div>

                <div class="row text-center">
                	<div class="col-sm-4 " >
                       
                       <canvas id="myCanvas" style="width:25.75em; margin-left:1.5em; height:10em;" >
                       <h2>SCHOOL</h2>
                       </canvas>
                       
                       <script>
                       var canvas = document.getElementById("myCanvas");
                       var ctx = canvas.getContext("2d");
                       ctx.fillStyle = "#ff8b88 ";
                       ctx.fillRect(50,131,182,25);
                       
                       ctx.font="28px MuseoSans_300";
                       ctx.fillStyle = "black";
                       ctx.textAlign = "center";
                       ctx.fillText("SCHOOL",140,140);
                       </script>
                       
                       <br>
                        <a href="login.php?l=<?php echo "s";?>"><input type="button" class="indexbuttons" value="LOGIN" title="LOGIN" ></a>
                        <br>
                        <a href="adminregistration.php"><input type="button" class="indexbuttons" value="REGISTER" title="REGISTER" ></a>
                        <br><br>
                        <a class="demo btnspecial" data-type="inline" href="#inlinecontentschool" style="padding:0.3em 3.9em; height:2em;text-decoration:none;" >ABOUT SCHOOL</a>
                        <br>
                        
						<!-- School lightbox -->
                        <div id="inlinecontentschool" style="display:none; height:100%; float:left; padding:20px;">
                        	<div style="float:left; padding:2em; text-align:justify;">
                            	
                                <h3><span class="gradientcolorone" style="font-weight:bold;">RELEVANT INFORMATION ABOUT SCHOOLS</span></h3>
								<p>"Studies have indicated that a whole school approach that involves the wider community is most effective for promoting long-lasting
positive changes in Intercultural Understanding. If these attributes are supported at the school, in the community and at home rather
than limiting them to time in the classroom then real change can be achieved."
                                </p>	<br>
                                <h5 style="font-weight:bold; text-align:left;">How can a school realization the cultural assets that lay within the communities that intersect it? </h5>
                                <h5 style="font-weight:bold; text-align:left;">What is a fast and efficient way to gain a snapshot into the demographics of your school, their communities and their homes?</h5> <p><br>
                                	<b>The Ancestry Atlas makes learning more about your student population simple.</b> Students answer questions about their birthplaces
and those of their family, the languages that are spoken at home and their religious beliefs. These answers are combined within our
tool which generates an eye-catching infographic that tells the story of your school visually. 
                                </p>
                                <p>"In addition to a whole school approach, it is also important to effectively engage the wider school community." Developing student
ICU and promoting ICU across the school community necessitates a holistic approach that involves school staff, family and other
community members. </p>
                                <p><b>Ancestry Atlas is a conversation starter.</b> A school census or survey is left in the domain of administration while a single picture tells a
story that can be shared by all. We have used this type of art based technique in a number of school workshops and it has been one
of the most effective techniques we've seen for beginning the conversation around culture. </p>
								<p><b>Ancestry Atlas helps you discover the most important areas of need.</b> To facilitate effective ICU, "Ernalsteen (2002) found that students
needed to have some prior knowledge of each other." In a study conducted by Steinbach (2010), a whole-school audit revealed they
were creating spatial segregation, which was contributing to an 'us versus them' mentality amongst the students (Steinbach, 2010).
The first step in facilitating positive change is getting to know one another and Ancestry Atlas facilitates this in a fun and engaging way. </p>
								
                                <h4 style="font-weight:bold; margin-bottom:0.1em;">Teaching resources aligned to the new federal curriculum</h4>
<p>Free teaching resources to assist you in facilitating Level 3 and 4 learning objectives:</p>
								<p> 
                                		<ul style="float:left;">
                                        <li>Reflect on Intercultural experiences</li>
                                        <li>Empathize with others</li>
                                        </ul>
                                
                                		<ul style="float:left;">
                                        <li>Develop Respect for Cultural Diversity</li>
                                        <li>Investigate Culture and Cultural Identity</li>
                                        </ul>
                                </p>
                            </div>
                        </div><!--lightbox ends-->
                        
                        
                    </div>
                    <div class="col-sm-4" >
                         <br><br>
                    	<img src="images/AA-logo-animation.gif" class="mainlogo " width="314">
                    </div>
                    <div class="col-sm-4 text-center">
                       
                       <canvas id="myCanvas1" style="width:25.75em; margin-left:1.5em; height:10em;" >
                       <h2>ORGANISATION</h2>
                       </canvas>
                       
                       <script>
                       var canvas = document.getElementById("myCanvas1");
                       var ctx = canvas.getContext("2d");
                       ctx.fillStyle = "#ff8b88 ";
                       ctx.fillRect(50,131,182,25);
                       
                       ctx.font="28px MuseoSans_300";
                       ctx.fillStyle = "black";
                       ctx.textAlign = "center";
                       ctx.fillText("ORGANISATION",140,138);
                       
                       </script>
                        <br>
                        <a href="login.php?l=<?php echo "o";?>"><input type="button" class="indexbuttons" value="LOGIN" title="LOGIN"  ></a>
                        <br>
                        <a href="adminregistration.php"><input type="button" class="indexbuttons" value="REGISTER" title="REGISTER" ></a>
                        <br><br>
                        <a class="demo btnspecial" data-type="inline" href="#inlinecontentorg" style="padding:0.3em 2.3em; height:2em;text-decoration:none;" >ABOUT ORGANISATION</a>
                        <br>
                               
                               
                               <!-- ORG lightbox -->
                        <div id="inlinecontentorg" style="display:none; height:100%; float:left; padding:20px;">
                        	<div style="float:left; padding:2em; text-align:justify;">
                            	
                                <h3><span class="gradientcolorone" style="font-weight:bold;">RELEVANT INFORMATION ABOUT ORGANISATION</span></h3>
                                <h5 style="font-weight:bold;">Numerous studies demonstrate that a diverse and inclusive workforce provides many advantages for organizations.</h5>
								<p>Using Ancestry Atlas to collect data on your organization can help you reveal your diversity and inclusion potential with greater precision and confidence.
                                </p>	
                                <h5 style="font-weight:bold; text-align:left;">What does diversity and inclusion bring to an organization?</h5>
                                
                                		<ul style="float:left;">
                                        <li><span style="font-weight:bold;">Engagement and inclusion</span> are separate but related concepts. In particular we found that engagement is an outcome of diversity and inclusion. Whilst those who feel highly included in a workplace with a low commitment to diversity are more engaged (67%) compared to those in a workplace with high diversity and low levels of inclusion (20%), it is the combined focus on diversity and inclusion which delivers the highest levels of engagement (101%).</li>
                                        
                                        <li><span style="font-weight:bold;">Higher management team performance:</span> Managements with a high degree of knowledge-based diversity generally achieve higher management team performance (Rodan & Galunic, 2004).</li>
                                        <li><span style="font-weight:bold;">Higher achieving teams:</span> Management teams possessing high cultural intelligence gained through ethnic and national diversity are higher achievers (Groves & Feyerherm, 2011).</li>
                                        <li><span style="font-weight:bold;">Attracting new talent: </span>New generations are attracted by companies with a diverse profile: 60% of candidates in a StepStone study from 2013 responded that it is 'very important' or 'important' that their workplace is inclusive regardless of nationality, religion, sexual orientation, gender and disability.</li>
                                        <li><span style="font-weight:bold;">Innovation:</span> Harvard Business Review published a study showing how diversity in leadership both unlocks innovation and drives market growth (Hewlett, Marshall & Sherbin, 2013) Studies also demonstrate that the more diverse organisations are, the greater their prospects of taking out new patents, resolving complex problems and realising innovations (Justesen, 2015). In their meta-study, Stahl, Maznevski, Voigt & Johnson (2009) demonstrate that diverse teams are more innovative and come in on-budget and on-time.
</li>
                                        <li><span style="font-weight:bold;">Insight into the market:</span> As noted by Justesen (2015), diversity, especially of gender, yields brighter ideas, more perspectives and deeper insights into the market, which allow good services to be adjusted to the target audience. A Gallup study from 2014 of 800 business units within two large service enterprises, revealed that the diverse units earned 19% more than non-diverse units. Diversely composed managements result in a more customer-oriented organisation (Hewlett, Marshall & Sherbin, 2013; McKinsey, 2015).</li>
                                        
                                        </ul>
                                
                                	
                                
                            </div>
                        </div>   <!--lightbox ends-->              

                    
                    </div>
                </div>
               
               
               
               <div class="col-sm-12">
               		<div class="col-sm-3"></div>
                    <div class="col-sm-6" style=" border-top:#9e9e9e 2px solid; margin-top:5em; "></div>
                    <div class="col-sm-3"></div>
               
               </div>
               
               <div class="col-sm-12 text-center" style="margin-top:1em;">
               		<h5 style="font-weight:bold;">CONNECT</h5>
                    <p>Many groups know very little about one another's diversity; their ancestry, the languages they speak or their beliefs.<br>
                       Ancestry Atlas makes this simple. Just invite your group, answer questions and then watch the information come to life in a graphic.</p>
                       
                       
                       <h5 style="font-weight:bold; margin-top:1em;">SHARE</h5>
                    <p>Share the Ancestry Atlas image across the world or print and post it on the wall.</p>
               </div>
               
               
                 <div class="col-sm-12">
               		<div class="col-sm-3"></div>
                    <div class="col-sm-6" style=" border-top:#9e9e9e 2px solid; margin-top:1em; "></div>
                    <div class="col-sm-3"></div>
               
               </div>
                   
        	</div>
            
			<div class="col-sm-2"></div>

        </div>
        
     
  
  
    </div>
  
   </div>
    
  <?php 
include 'footer.php';
?>

</body>
</html>
