<div class="row text-center">
        <div class="col-sm-12 header">
            <a href="teacherpanel.php"><img src="images/logo.png" title="Ancestry Atlas" alt="Ancestry Atlas"></a>
            <a href="teacherpanel.php?logoutrequest" style="float: right; color: #fff; text-decoration:none; ">LOGOUT</a>
        </div>
</div>
