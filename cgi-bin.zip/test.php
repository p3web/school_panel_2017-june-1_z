<!DOCTYPE html>
<html>
<body>

<?php
date_default_timezone_set("Australia/Melbourne");
echo "The time is " . date("h:i:sa"). "<br>";
echo "Today is " . date("d/m/Y") . "<br>";
?>

</body>
</html>