<div id="footer" style="background-color:#ff8c87;">
      <div class="container" >
        <p class="text-muted">
            <span style="float:left; color:#FFF;"> &copy; <?php echo date('Y');?> CULTURAL INFUSION OR ITS AFFILIATED COMPANIES. ALL RIGHTS RESERVED.</span>
            <span style="float:right; color:#FFF;">
            	<a style="color:#FFF;" target="_blank" href="HELP.pdf" title="HELP">HELP</a> | 
            	<a style="color:#FFF;" href="privacy.php" title="PRIVACY">PRIVACY</a> |
                <a style="color:#FFF;" href="contactus.php" title="CONTACT US">CONTACT US</a>  
                
            </span>
        </p>
        
      </div>
 </div>