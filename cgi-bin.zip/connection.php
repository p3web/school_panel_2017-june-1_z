<?php

$servername = "localhost";
$username = "ancestry_atlas";
$password = "]?7W%4yATmA?";
$con = mysql_connect($servername, $username, $password);
$db = mysql_select_db("ancestry_atlas",$con);

/*
if (!$conn) {
    die("Connection failed with Database: " . mysql_error());
	
}

echo "Connected successfully";

*/

?>